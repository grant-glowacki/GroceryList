import React, { Component } from 'react';
import { render } from 'react-dom';
import './style.css';


class GroceryList extends Component {
  constructor() {
    super();
    this.state = {
      groceryList: ['bread','eggs', 'milk']
    };
    this.addItem = this.addItem.bind(this);
  }
  componentWillMount() {
    this.getList();
  };

  getList() {
    fetch('https://country-api-grantglowacki834408.codeanyapp.com/countries').then(
      response => { 
    if (response.ok) {
      return response.json(); 
    }
    throw new Error('Request failed!');
    }, networkError => {
    console.log(networkError.message);
    }).then(jsonResponse => {
      let returnedList = jsonResponse;
    this.setState({groceryList: returnedList})});
  };


  addItem(item) {
    if (item !== '') {
      fetch('https://country-api-grantglowacki834408.codeanyapp.com/countries',
      {
        method: 'POST',
        body: item,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      }).then(
        (response) => {
          response.json()
          .then((jsonResponse) => this.setState({groceryList: jsonResponse}));
        }
      )
      let newList = this.state.groceryList.push(item);
      this.setState({groceryList: newList});
      //Not able to create a real POST since I have no API, so I just wrote what it would be
    }
    else {
      return;
    }
  }
 

  render() {
    const list = this.state.groceryList.map((item) => <ul>{item}</ul>);
    return (
      <div>
      Things to Buy:
        {list}
        <form onSubmit={this.addItem(/*_inputElement.value*/)}>
            <input ref={(a) => this._inputElement = a}
            placeholder="Enter Item Name Here">
            </input>
            <button type="submit">Add Item</button>
          </form>
      </div>
    );
  }; 

}
export default GroceryList;